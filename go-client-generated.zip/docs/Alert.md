# Alert

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ModifiedOn** | **int64** |  | [optional] [default to null]
**Name** | **string** |  | [default to null]
**SegmentCondition** | [**SegmentCondition**](SegmentCondition.md) |  | [optional] [default to null]
**Timespan** | **int64** |  | [optional] [default to null]
**Severity** | **int32** |  | [optional] [default to null]
**CreatedOn** | **int64** |  | [optional] [default to null]
**Enabled** | **bool** |  | [optional] [default to null]
**NotificationCount** | **int32** |  | [optional] [default to null]
**TeamId** | **int64** |  | [optional] [default to null]
**Version** | **int32** |  | [optional] [default to null]
**SegmentBy** | [**[]Condition**](Condition.md) |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]
**Id** | **int64** |  | [optional] [default to null]
**Condition** | [**Condition**](Condition.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


